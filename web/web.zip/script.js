// $(document).ready(function(){

// document.getElementById('button').addEventListener('click', () => {
//   document.getElementById('fileInput').click()
// });

// });


